<?php


define('DB_HOST', 'localhost');
define('DB_NAME', 'group');
define('DB_USER', 'root');
define('DB_PASS', '');
